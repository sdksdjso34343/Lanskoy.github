# Discord bots website template
Stunning website with good UI design for the new Discord bots, built with Bootstrap and has many ready-made pages to edit by your own.

## main page:

![Screenshot1](https://raw.githubusercontent.com/Hadi-Koubeissi/Discord-bot-website-template/master/Screenshot/1.PNG)

![Screenshot2](https://raw.githubusercontent.com/Hadi-Koubeissi/Discord-bot-website-template/master/Screenshot/2.PNG)

![Screenshot3](https://raw.githubusercontent.com/Hadi-Koubeissi/Discord-bot-website-template/master/Screenshot/3.PNG)

## command page:
![Screenshot4](https://raw.githubusercontent.com/Hadi-Koubeissi/Discord-bot-website-template/master/Screenshot/4.PNG)

and more pages I couldn't Screenshot them

# Installing
Download or fork the repo

`git clone https://github.com/Hadi-Koubeissi/Discord-bot-website-template`

open index.html with any code editor and edit the name or logo and then have fun.

## Built With: 

* [Bootstrap](https://getbootstrap.com/) - The web framework used
* [Jquery](https://jquery.com/) - For scripts

## Authors

[Hadi-Koubeissi](https://github.com/Hadi-Koubeissi)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details
